export class Mcq {
    constructor(
        public id: number,
        public question: string) { }
    }